﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication3.Controllers
{
    public class FormController : Controller
    {
        [HttpGet]
        public IActionResult Index(string name, string height, string weight)
        {
                ViewData["name"] = (name).ToUpper();
                ViewData["height"] = (height).ToUpper();
                ViewData["weight"] = (weight).ToUpper();
            return View();
        }

            [HttpPost]
            [ActionName("Index")]
            public IActionResult IndexPost(string name, string height, string weight)
            {
                ViewData["name"] = (name).ToUpper();
                ViewData["height"] = (height).ToUpper();
                ViewData["weight"] = (weight).ToUpper();
            return View();
            }


       
    }
}
