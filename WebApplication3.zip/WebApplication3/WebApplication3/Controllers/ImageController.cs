﻿using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;

namespace WebApplication3.Controllers
{
    public class ImageController : Controller
    {
        [HttpGet]
        public IActionResult Index(string name)
        {
            ViewData["name"] = name ?? "Nie ma takiego obrazu";
            return View();
        }
    }
}
