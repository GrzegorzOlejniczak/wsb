using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class ShowController : Controller
    {
        [HttpGet]
        public IActionResult Index(string name)
        {
            ViewData["name"] = name ?? "nieznajomy";
            return View();
        }
        [HttpPost]
        [ActionName("Index")]
        public IActionResult IndexPost(string name)
        {
            ViewData["name"] = (name ?? "nieznajomy").ToUpper();
            return View();
        }
    }
}
